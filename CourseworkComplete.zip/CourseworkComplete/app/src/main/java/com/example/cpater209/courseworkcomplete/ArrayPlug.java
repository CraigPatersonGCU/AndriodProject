package com.example.cpater209.courseworkcomplete;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//An adapter used to as layer to parse information


class ArrayPlug extends ArrayAdapter<ParsedInfo> implements Serializable {

    private Context context;
    private ArrayList<ParsedInfo> contentDetails;


    public ArrayPlug(Context context, int resource, List<ParsedInfo> objects) {
        super(context, resource, objects);

        this.context = context;
        this.contentDetails = (ArrayList)objects;
    }



    public View getView(int position, View convertView, ViewGroup parent) {


        ParsedInfo parsedInfo = contentDetails.get(position);


        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.layout, null);

        if (parsedInfo.getArticleDescription().contains("Start Date")) {
            String pattern = " EEEE, dd MMMM yyyy";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

            String[] split = parsedInfo.getArticleDescription().split("<br />");
            String string1 = split[0];
            String string2 = split[1];

            string1 = string1.substring(string1.indexOf(':') + 1, string1.indexOf('-'));
            string2 = string2.substring(string2.indexOf(':') + 1, string2.indexOf('-'));

            try {
                Date date = simpleDateFormat.parse(string1);
                Date date2 = simpleDateFormat.parse(string2);
                long oppDay = Math.abs(date.getTime() - date2.getTime());
                long dtDays = oppDay / (24 * 60 * 60 * 1000);
                if (dtDays != 1) {
                    dtDays = dtDays + 1;
                }


            } catch (ParseException e) {
                e.printStackTrace();
            }



        }

        TextView articleTitleID = (TextView) view.findViewById(R.id.articleTitle);
        TextView description = (TextView) view.findViewById(R.id.articleDescription);





        articleTitleID.setText(parsedInfo.getArticleTitle());
        description.setText(parsedInfo.getArticleDescription());



        return view;
    }
}