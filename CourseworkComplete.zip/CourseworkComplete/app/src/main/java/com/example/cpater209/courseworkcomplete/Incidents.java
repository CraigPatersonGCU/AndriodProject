package com.example.cpater209.courseworkcomplete;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

//Class to define current incedents on the road


public class Incidents extends AppCompatActivity {

    private String incidentsHTTP ="https://trafficscotland.org/rss/feeds/currentincidents.aspx";

    private List<ParsedInfo> incidentArrayWrapper;
    private ArrayAdapter<ParsedInfo> incidentArrayPlug;

    private ListView incidentsV;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.incidentsdesign);

        incidentsV = (ListView) findViewById(R.id.incidentsListView);
        incidentArrayWrapper = (ArrayList<ParsedInfo>)getIntent().getSerializableExtra("incidentsList");
        incidentArrayPlug = new ArrayPlug(Incidents.this, 0, incidentArrayWrapper);

        incidentsV.setAdapter(incidentArrayPlug);
        incidentsV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView,
                                    View view, int position, long rowId) {

                ParsedInfo parsedInfo = incidentArrayWrapper.get(position);

                Intent intent = new Intent(Incidents.this, Information.class);
                intent.putExtra("Title", parsedInfo.getArticleTitle());
                intent.putExtra("Description", parsedInfo.getArticleDescription());
                intent.putExtra("Link", parsedInfo.getArticleLink());
                intent.putExtra("Location", parsedInfo.getArticleLocation());
                intent.putExtra("Author", parsedInfo.getArticleAuthor());
                intent.putExtra("Comments Section", parsedInfo.getArticleCommentSection());
                intent.putExtra("Article Release Date", parsedInfo.getArticleReleaseDate());
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
