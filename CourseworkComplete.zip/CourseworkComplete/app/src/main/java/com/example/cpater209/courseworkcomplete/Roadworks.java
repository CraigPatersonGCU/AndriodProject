package com.example.cpater209.courseworkcomplete;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.joda.time.DateTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


//A class used to sort the desgin of the roadworks

public class Roadworks extends AppCompatActivity {

    private List<ParsedInfo> roadworksList;
    private List<ParsedInfo> selectedList;

    private ArrayAdapter<ParsedInfo> roadworksAdapter;
    private ArrayAdapter<ParsedInfo> selectedAdapter;

    private Button calanderButton;
    private Button searchButton;

    private EditText enterLocation;
    private ListView roadworksListview;
    private ListView selectedListView;
    Date selectedDate;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.roadworksdesign);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        calanderButton = (Button) findViewById(R.id.calanderButton);
        searchButton = (Button) findViewById(R.id.searchButton);
        searchButton.setInputType(0);
        enterLocation = (EditText) findViewById(R.id.enterLocation);

        roadworksListview = (ListView) findViewById(R.id.roadworksListView);
        selectedListView = (ListView) findViewById(R.id.selectedListView);

        selectedListView.setVisibility(View.INVISIBLE);



        roadworksList = (ArrayList<ParsedInfo>)getIntent().getSerializableExtra("roadworksList");
        selectedList = new ArrayList<ParsedInfo>();

        roadworksAdapter = new ArrayPlug(Roadworks.this, 0, roadworksList);
        roadworksListview.setAdapter(roadworksAdapter);

        roadworksListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView,
                                    View view, int position, long rowId) {

                ParsedInfo parsedInfo = roadworksList.get(position);

                Intent intent = new Intent(Roadworks.this, Information.class);
                intent.putExtra("Title", parsedInfo.getArticleTitle());
                intent.putExtra("Description", parsedInfo.getArticleDescription());
                intent.putExtra("Link", parsedInfo.getArticleLink());
                intent.putExtra("Location", parsedInfo.getArticleLocation());
                intent.putExtra("Author", parsedInfo.getArticleAuthor());
                intent.putExtra("Comments", parsedInfo.getArticleCommentSection());
                intent.putExtra("ArticleReleaseDate", parsedInfo.getArticleReleaseDate());
                startActivity(intent);
            }
        });




        final Calendar myCalendar = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                selectedList = new ArrayList<ParsedInfo>(); //Reset each time a new date is selected
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                selectedDate = myCalendar.getTime();
                getSelectedDates();
                if (selectedList.size() > 0) {
                    selectedAdapter = new ArrayPlug(Roadworks.this, 0, selectedList);
                    selectedListView.setAdapter(selectedAdapter);
                    selectedListView.setVisibility(View.VISIBLE);
                    roadworksListview.setVisibility(View.INVISIBLE);
                }
                else
                {
                    displayErrorMessage();
                    selectedListView.setVisibility(View.INVISIBLE);
                    roadworksListview.setVisibility(View.VISIBLE);
                }
            }

        };

        selectedListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView,
                                    View view, int position, long rowId) {

                ParsedInfo parsedInfo = roadworksList.get(position);

                Intent intent = new Intent(Roadworks.this, Information.class);
                intent.putExtra("Title", parsedInfo.getArticleTitle());
                intent.putExtra("Description", parsedInfo.getArticleDescription());
                intent.putExtra("Link", parsedInfo.getArticleLink());
                intent.putExtra("Location", parsedInfo.getArticleLocation());
                intent.putExtra("Author", parsedInfo.getArticleAuthor());
                intent.putExtra("Comments", parsedInfo.getArticleCommentSection());
                intent.putExtra("ArticleRealseDate", parsedInfo.getArticleReleaseDate());
                startActivity(intent);
            }
        });

        calanderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(Roadworks.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try  {
                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                } catch (Exception e) {

                }

                selectedList = new ArrayList<ParsedInfo>(); //Reset each time a new date is selected
                String getTxtInput = enterLocation.getText().toString();
                getRoadworksWithName(getTxtInput);
                if (selectedList.size() > 0) {
                    selectedAdapter = new ArrayPlug(Roadworks.this, 0, selectedList);
                    selectedListView.setAdapter(selectedAdapter);
                    selectedListView.setVisibility(View.VISIBLE);
                    roadworksListview.setVisibility(View.INVISIBLE);
                }
                else
                {
                    displayErrorMessage();
                    selectedListView.setVisibility(View.INVISIBLE);
                    roadworksListview.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void displayErrorMessage() {
        Toast.makeText(Roadworks.this,
                "No entries found!",
                Toast.LENGTH_LONG).show();
    }

    public void getRoadworksWithName(String searchTerm) {
        for (ParsedInfo t : roadworksList) {
            String search = t.getArticleTitle();
            if (search.toLowerCase().indexOf(searchTerm.toLowerCase()) != -1) {
                selectedList.add(t);
            }
        }
    }

    public void getSelectedDates() {
        for(ParsedInfo t : roadworksList) {
            String pattern = "dd MMMM yyyy";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

            DateTime dateSelected = new DateTime(selectedDate);
            String[] parts = t.getArticleDescription().split("<br />");
            String part1 = parts[0];
            String part2 = parts[1];

            part1 = part1.substring(part1.indexOf(',') + 1, part1.indexOf('-')).substring(1);
            part2 = part2.substring(part2.indexOf(',') + 1, part2.indexOf('-')).substring(1);

            try {
                Date from = simpleDateFormat.parse(part1);
                Date to = simpleDateFormat.parse(part2);

                DateTime startDate = new DateTime(from);
                DateTime endDate = new DateTime(to);

                for(DateTime currentdate=startDate; currentdate.isBefore(endDate);currentdate=currentdate.plusDays(1)) {
                    String actualDate = currentdate.toString().substring(0,10);
                    String selectedDate = dateSelected.toString().substring(0,10);
                    if (actualDate.equals(selectedDate)) {
                        selectedList.add(t);
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

}
