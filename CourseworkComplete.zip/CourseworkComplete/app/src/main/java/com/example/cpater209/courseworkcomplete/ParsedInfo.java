package com.example.cpater209.courseworkcomplete;

import java.io.Serializable;

//Information is parsed into the system

public class ParsedInfo implements Serializable
{
    private String articleTitle;
    private String articleDescription;
    private String articleLink;
    private String articleLocation;
    private String articleAuthor;
    private String articleCommentSection;
    private String articleReleaseDate;

    public ParsedInfo()
    {
        articleTitle = "";
        articleDescription = "";
        articleLink = "";
        articleLocation = "";
        articleAuthor = "";
        articleCommentSection = "";
        articleReleaseDate = "";
    }

    public ParsedInfo(String date)
    {
        articleDescription = date;
    }

    public ParsedInfo(String articleTitle1, String articleDescription1, String articleLink1, String articleLocation1, String articleAuthor1, String articleCommentSection1, String articleReleaseDate1)
    {
        articleTitle = articleTitle1;
        articleDescription = articleDescription1;
        articleLink = articleLink1;
        articleLocation = articleLocation1;
        articleAuthor = articleAuthor1;
        articleCommentSection = articleCommentSection1;
        articleReleaseDate = articleReleaseDate1;
    }

    public ParsedInfo(String atitle , String adescription, String alink, String alocation)
    {
        articleTitle = atitle;
        articleDescription = adescription;
        articleLink = alink;
        articleLocation = alocation;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public String getArticleDescription() {
        return articleDescription;
    }

    public void setArticleDescription(String articleDescription) {
        this.articleDescription = articleDescription;
    }

    public String getArticleLink() {
        return articleLink;
    }

    public void setArticleLink(String articleLink) {
        this.articleLink = articleLink;
    }

    public String getArticleLocation() {
        return articleLocation;
    }

    public void setArticleLocation(String articleLocation) {
        this.articleLocation = articleLocation;
    }

    public String getArticleAuthor() {
        return articleAuthor;
    }

    public void setArticleAuthor(String articleAuthor) {
        this.articleAuthor = articleAuthor;
    }

    public String getArticleCommentSection() {
        return articleCommentSection;
    }

    public void setArticleCommentSection(String articleCommentSection) {
        this.articleCommentSection = articleCommentSection;
    }

    public String getArticleReleaseDate() {
        return articleReleaseDate;
    }

    public void setArticleReleaseDate(String articleReleaseDate) {
        this.articleReleaseDate = articleReleaseDate;
    }



}