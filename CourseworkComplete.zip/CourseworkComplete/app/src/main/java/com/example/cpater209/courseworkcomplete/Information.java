package com.example.cpater209.courseworkcomplete;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

//A class used to sort parsed information

public class Information extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informationdesign);





        TextView t = (TextView) findViewById(R.id.articleTitle);
        TextView d = (TextView) findViewById(R.id.articleDescription);
        TextView li = (TextView) findViewById(R.id.articleLink);
        TextView lo = (TextView) findViewById(R.id.articleLocation);
        TextView aut = (TextView) findViewById(R.id.articleAuthor);
        TextView com = (TextView) findViewById(R.id.articleCommentSection);
        TextView rel = (TextView) findViewById(R.id.articleReleaseDate);



        Intent intent = getIntent();

        String articleTitle = intent.getStringExtra("articleTitle");
        String articleDescription = intent.getStringExtra("articleDescription");
        String articleLink = intent.getStringExtra("articleLink");
        String articleLocation = intent.getStringExtra("articleLocation");
        String articleAuthor = intent.getStringExtra("articleAuthor");
        String articleCommentsSection = intent.getStringExtra("articleCommentsSection");
        String articleReleaseDate = intent.getStringExtra("articleReleaseDate");




        t.setText(articleTitle);
        d.setText(articleDescription);
        li.setText(articleLink);
        lo.setText(articleLocation);
        aut.setText(articleAuthor);
        com.setText(articleCommentsSection);
        rel.setText(articleReleaseDate);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



}