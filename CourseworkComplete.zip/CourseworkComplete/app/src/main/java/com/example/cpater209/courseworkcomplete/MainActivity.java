package com.example.cpater209.courseworkcomplete;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    String pattern = " EEEE, dd MMMM yyyy";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

    private String roadworksHTTP = "http://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private String incidentsHTTP = "http://trafficscotland.org/rss/feeds/currentincidents.aspx";
    private Button incidentButton;
    private Button roadworksButton;
    private ArrayList<ParsedInfo> incidentList;
    private ArrayList<ParsedInfo> roadWorksList;
    private ArrayAdapter<ParsedInfo> incidentAdapter;
    private ArrayAdapter<ParsedInfo> roadworksAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        incidentButton = (Button) findViewById(R.id.incidentButton);
        roadworksButton = (Button) findViewById(R.id.roadworksButton);

        roadWorksList = new ArrayList<ParsedInfo>();
        incidentList = new ArrayList<ParsedInfo>();

        new FetchFeedTask().execute((Void) null);

        incidentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent myIntent = new Intent(MainActivity.this, Incidents.class);
                myIntent.putExtra("incidentsList", incidentList);
                MainActivity.this.startActivity(myIntent);

            }
        });

        roadworksButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, Roadworks.class);
                myIntent.putExtra("roadworksList", roadWorksList);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }

    public static ArrayList<ParsedInfo> parseFeed(InputStream inputStream) throws XmlPullParserException, IOException {
        String title = null;
        String link = null;
        String description = null;
        String georss = null;
        String author = null;
        String comments = null;
        String pubDate = null;
        boolean isItem = false;
        ArrayList<ParsedInfo> items = new ArrayList<>();

        try {
            XmlPullParser xmlPullParser = Xml.newPullParser();
            xmlPullParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            xmlPullParser.setInput(inputStream, null);

            xmlPullParser.nextTag();
            while (xmlPullParser.next() != XmlPullParser.END_DOCUMENT) {
                int eventType = xmlPullParser.getEventType();

                String name = xmlPullParser.getName();
                if (name == null)
                    continue;

                if (eventType == XmlPullParser.END_TAG) {
                    if (name.equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    continue;
                }

                if (eventType == XmlPullParser.START_TAG) {
                    if (name.equalsIgnoreCase("item")) {
                        isItem = true;
                        continue;
                    }
                }

                Log.d("MainActivity", "Parsing name ==> " + name);
                String result = "";
                if (xmlPullParser.next() == XmlPullParser.TEXT) {
                    result = xmlPullParser.getText();
                    xmlPullParser.nextTag();
                }

                if (name.equalsIgnoreCase("title")) {
                    title = result;
                } else if (name.equalsIgnoreCase("description")) {
                    description = result;
                } else if (name.equalsIgnoreCase("link")) {
                    link = result;
                } else if (name.equalsIgnoreCase("georss:point")) {
                    georss = result;
                } else if (name.equalsIgnoreCase("author")) {
                    author = result;
                    if (author == "") {
                        author = "N/A";
                    }
                } else if (name.equalsIgnoreCase("comments")) {
                    comments = result;
                    if (comments == "") {
                        comments = "N/A";
                    }
                } else if (name.equalsIgnoreCase("pubDate")) {
                    pubDate = result;
                }


                if (description != null && description.contains("<br\\s*/>")) {
                    description.replace("<br\\s*/>", " ");
                }

                if (title != null && link != null && description != null && georss != null) {
                    if (isItem) {
                        ParsedInfo item = new ParsedInfo(title, description, link, georss, author, comments, pubDate);
                        items.add(item);
                    }

                    title = null;
                    description = null;



                    isItem = false;
                }
            }

            return items;
        } finally {
            inputStream.close();
        }
    }



    public final class FetchFeedTask extends AsyncTask<Void, Void, Boolean> {


        @Override
        protected Boolean doInBackground(Void... voids) {

            String urlLink = incidentsHTTP;

            if (TextUtils.isEmpty(urlLink))
                return false;

            try {
                if (!urlLink.startsWith("http://") && !urlLink.startsWith("https://"))
                    urlLink = "http://" + urlLink;

                URL url = new URL(incidentsHTTP);
                InputStream inputStream = url.openConnection().getInputStream();
                incidentList = MainActivity.parseFeed(inputStream);

                URL url2 = new URL(roadworksHTTP);
                InputStream inputStream2 = url2.openConnection().getInputStream();
                roadWorksList = MainActivity.parseFeed(inputStream2);


                return true;
            } catch (IOException e) {
                Log.e(TAG, "Error", e);
            } catch (XmlPullParserException e) {
                Log.e(TAG, "Error", e);
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {


            if (success) {

                incidentAdapter = new ArrayPlug(MainActivity.this, 0, incidentList);
                roadworksAdapter = new ArrayPlug(MainActivity.this, 0, roadWorksList);


            }
        }
    }
}
